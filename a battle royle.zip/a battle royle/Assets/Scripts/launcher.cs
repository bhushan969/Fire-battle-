using UnityEngine;
using Photon.Pun;      // Photon Unity Networking
using Photon.Realtime; // Room/Connection callbacks
using UnityEngine.SceneManagement;

public class Launcher : MonoBehaviourPunCallbacks
{
    [Header("Photon Settings")]
    public string gameVersion = "1.0";
    public byte maxPlayersPerRoom = 10;

    void Start()
    {
        Debug.Log("🚀 Connecting to Photon...");
        ConnectToServer();
    }

    public void ConnectToServer()
    {
        if (!PhotonNetwork.IsConnected)
        {
            PhotonNetwork.AutomaticallySyncScene = true; // sync scene for all players
            PhotonNetwork.GameVersion = gameVersion;
            PhotonNetwork.ConnectUsingSettings();
        }
    }

    // When connected to Photon Master server
    public override void OnConnectedToMaster()
    {
        Debug.Log("✅ Connected to Photon Master.");
        PhotonNetwork.JoinRandomRoom();
    }

    // If joining random room fails → create one
    public override void OnJoinRandomFailed(short returnCode, string message)
    {
        Debug.Log("⚠️ No room found, creating a new one...");
        PhotonNetwork.CreateRoom(null, new RoomOptions { MaxPlayers = maxPlayersPerRoom });
    }

    // Once joined → load BattleScene
    public override void OnJoinedRoom()
    {
        Debug.Log("🎮 Joined a room!");
        if (PhotonNetwork.IsMasterClient)
        {
            Debug.Log("🟢 Loading BattleScene...");
            PhotonNetwork.LoadLevel("BattleScene"); // load scene for everyone
        }
    }

    public override void OnDisconnected(DisconnectCause cause)
    {
        Debug.LogWarningFormat("❌ Disconnected from Photon: {0}", cause);
    }
}