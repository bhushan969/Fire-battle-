using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 5f;
    public float jumpForce = 5f;
    public GameObject bulletPrefab;
    public Transform firePoint;

    private Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();

        // Assign Player material if not already
        Renderer rend = GetComponent<Renderer>();
        if (rend != null)
        {
            Material playerMat = Resources.Load<Material>("Player");
            if (playerMat != null)
                rend.material = playerMat;
        }
    }

    void Update()
    {
        // Movement
        float moveX = Input.GetAxis("Horizontal");
        float moveZ = Input.GetAxis("Vertical");
        Vector3 move = new Vector3(moveX, 0, moveZ) * moveSpeed;
        rb.velocity = new Vector3(move.x, rb.velocity.y, move.z);

        // Jump
        if (Input.GetButtonDown("Jump"))
        {
            rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
        }

        // Fire bullet
        if (Input.GetButtonDown("Fire1"))
        {
            Shoot();
        }
    }

    void Shoot()
    {
        if (bulletPrefab != null && firePoint != null)
        {
            GameObject bullet = Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);
            Rigidbody brb = bullet.GetComponent<Rigidbody>();
            brb.velocity = firePoint.forward * 20f;

            // Set Bullet material
            Renderer rend = bullet.GetComponent<Renderer>();
            if (rend != null)
            {
                Material bulletMat = Resources.Load<Material>("Bullet");
                if (bulletMat != null)
                    rend.material = bulletMat;
            }

            Destroy(bullet, 3f); // auto-destroy bullet after 3 sec
        }
    }
}