using UnityEngine;
using Photon.Pun;

public class Bullet : MonoBehaviourPun
{
    public float speed = 20f;
    public int damage = 20;
    public float lifeTime = 3f;

    private Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.velocity = transform.forward * speed;

        // Auto destroy after lifetime
        Destroy(gameObject, lifeTime);

        // Apply Bullet material
        Renderer rend = GetComponent<Renderer>();
        if (rend != null)
        {
            Material bulletMat = Resources.Load<Material>("Bullet");
            if (bulletMat != null)
                rend.material = bulletMat;
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        // If it hit a player
        if (collision.gameObject.CompareTag("Player"))
        {
            PlayerHealth health = collision.gameObject.GetComponent<PlayerHealth>();
            if (health != null)
            {
                health.TakeDamage(damage);
            }
        }

        // Destroy bullet after collision (only owner destroys it)
        if (photonView.IsMine)
        {
            PhotonNetwork.Destroy(gameObject);
        }
    }
}