using UnityEngine;
using Photon.Pun;   // For networked instantiation

public class GameManager : MonoBehaviourPunCallbacks
{
    [Header("Prefabs")]
    public GameObject playerPrefab;
    public GameObject groundPrefab;

    void Start()
    {
        Debug.Log("🎮 GameManager started.");

        // ✅ Spawn Ground
        if (groundPrefab != null)
        {
            GameObject ground = Instantiate(groundPrefab, Vector3.zero, Quaternion.identity);
            ground.transform.localScale = new Vector3(50, 1, 50);

            // Apply Ground.mat
            Renderer rend = ground.GetComponent<Renderer>();
            if (rend != null)
            {
                Material groundMat = Resources.Load<Material>("Ground");
                if (groundMat != null)
                    rend.material = groundMat;
            }
        }

        // ✅ Spawn Player (via Photon)
        if (playerPrefab != null)
        {
            Vector3 randomSpawn = new Vector3(Random.Range(-10, 10), 2, Random.Range(-10, 10));
            PhotonNetwork.Instantiate(playerPrefab.name, randomSpawn, Quaternion.identity);
        }
        else
        {
            Debug.LogError("❌ PlayerPrefab not assigned in GameManager!");
        }
    }

    // Called when a player leaves the room
    public override void OnLeftRoom()
    {
        Debug.Log("↩️ Left the room. Returning to LauncherScene...");
        PhotonNetwork.LoadLevel("LauncherScene");
    }
}